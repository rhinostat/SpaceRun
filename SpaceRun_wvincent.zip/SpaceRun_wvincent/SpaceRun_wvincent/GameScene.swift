//
//  GameScene.swift
//  SpaceRun_wvincent
//
//  Created by Vincent, II, William on 4/29/19.
//  Copyright © 2019 CVTC William Vincent II. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    // MARK: Constants
    private let SpaceshipNodeName = "ship"
    private let PhotonTorpedoNodeName = "photon"
    private let ObstacleNodeName = "obstacle"
    private let PowerupNodeName = "powerup"
    private let HUDNodeName = "hud"
    private let HealthNodeName = "health"
    private let SpaceshipShieldNodeName = "shield2"
    
    // MARK: - Variables
    private weak var shipTouch: UITouch?
    private var lastUpdateTime: TimeInterval = 0
    private var lastShotFireTime: TimeInterval = 0
    private let defaultFireRate: Double = 0.5
    private var shipFireRate: Double = 0.5
    private let powerUpDuration: TimeInterval = 5.0
    private var tapGesture: UITapGestureRecognizer?
    
    // MARK: - RUBRIC 1 and 2
    private var shipHealthRate: CGFloat = 2.0
    
    typealias endGameCallbackType = () -> Void
    var endGameCallback: endGameCallbackType?
    
    var easyMode: Bool = true
    
    
    // MARK: - Sounds
    private let shootSound: SKAction = SKAction.playSoundFileNamed("laserShot.wav", waitForCompletion: false)
    private let obstacleExplodeSound: SKAction = SKAction.playSoundFileNamed("darkExplosion.wav", waitForCompletion: false)
    private let shipExplodeSound: SKAction = SKAction.playSoundFileNamed("explosion.wav", waitForCompletion: false)
    private let impactSound: SKAction = SKAction.playSoundFileNamed("Space fusion ray.wav", waitForCompletion: false)
    private let powerSound: SKAction = SKAction.playSoundFileNamed("powerUpSound.wav", waitForCompletion: false)
    
    // MARK: - Explosions
    private let shipExplodeTemplate: SKEmitterNode = SKEmitterNode(fileNamed: "shipExplode.sks")!
    private let obstacleExplodeTemplate: SKEmitterNode = SKEmitterNode(fileNamed: "obstacleExplode.sks")!

    
    // MARK: - Initializers
    override init(size: CGSize) {
        super.init(size: size)
        setupGame(size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
        
    }
    // MARK: Game Setup
    func setupGame(_ size: CGSize) {
        let ship = SKSpriteNode(imageNamed: "Spaceship.png")
        ship.position = CGPoint(x: size.width/2.0, y: size.height/2.0)
        ship.size = CGSize(width: 40.0, height: 40.0)
        ship.name = SpaceshipNodeName
        addChild(ship)
        
        // Add ship thruster particle to our ship
        if let thrust = SKEmitterNode(fileNamed: "thrust.sks") {
            
            thrust.position = CGPoint(x: 0.0, y: -20.0)
            // Now, add the thrust as a child of our ship sprite so its
            // position is relative to the ship's position
            ship.addChild(thrust)
    }
        // MARK: - RUBRIC 14a
        let shield = SKSpriteNode(imageNamed: "shield2.png")
        shield.size = CGSize(width: 55.0, height: 55.0)
        shield.zPosition = -1
        shield.position = CGPoint(x: 0.0, y: 0.0)
        shield.name = SpaceshipShieldNodeName
        shield.alpha = 0.5
        
        ship.addChild(shield)
        
        addChild(StarField())
    
    // Set up HUD
    let hudNode = HUDNode()
    hudNode.name = HUDNodeName
    
    // By default, nodes will overlap (stack) according to the order in which
    // they were added to the scene.  If we don't set the zPosition property here,
    // the node will appear below everything we add later.
    hudNode.zPosition = 100.0
    
    // Set the position of the node to the center of the screen.  All of the
    // child nodes will be positioned relative to this parent node's origin
    hudNode.position = CGPoint(x: size.width/2.0, y: size.height/2.0)
    addChild(hudNode)
    
    hudNode.layoutForScene()
        
    // Start the game
    hudNode.startGame()
    
    }
    // MARK: - Touches
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            self.shipTouch = touch
            
        }
        
    }
    override func update(_ currentTime: TimeInterval) {
        
        if lastUpdateTime == 0 {
            lastUpdateTime = currentTime
            
        }
        
        // Calculate the time change (delta) since the last frame
        let timeDelta = currentTime - lastUpdateTime
        
        if let shipTouch = shipTouch {
            
            moveShipTowardPoint(shipTouch.location(in: self), timeDelta: timeDelta)
            
            if currentTime - lastShotFireTime > shipFireRate {
                
                // shoot a torpedo
                shoot()
                
                // reset the last fire time to current time
                lastShotFireTime = currentTime
                
            }
            
        }
        
        let thingProbability: Int
        if (self.easyMode) {
            thingProbability = 15
            
        } else {
            thingProbability = 30
            
        }
        
        if Int.random(in: 0..<1000) < thingProbability {
            dropThing()
            
        }
        
        checkCollisions()
        
        lastUpdateTime = currentTime
        
    }
    
    
    func moveShipTowardPoint(_ point: CGPoint, timeDelta: TimeInterval) {
        
        let shipSpeed = CGFloat(130)
        
        if let ship = self.childNode(withName: SpaceshipNodeName) {
            
            let distanceLeftToTravel = sqrt(pow(ship.position.x - point.x, 2) + pow(ship.position.y - point.y, 2))
            
            if distanceLeftToTravel > 4 {
                
                let distanceRemaining = CGFloat(timeDelta) * shipSpeed
                let angle = atan2(point.y - ship.position.y, point.x - ship.position.x)
                let xOffset = distanceRemaining * cos(angle)
                let yOffset = distanceRemaining * sin(angle)
                
                ship.position = CGPoint(x: ship.position.x + xOffset, y: ship.position.y + yOffset)
            }
        }
        
    }
    
    func shoot() {
        if let ship = self.childNode(withName: SpaceshipNodeName) {
            
            let photon = SKSpriteNode(imageNamed: PhotonTorpedoNodeName)
            
            photon.name = PhotonTorpedoNodeName
            
            // position the photon torpedo at the same position as our ship
            photon.position = ship.position
            
            // Add the photon to the scene
            self.addChild(photon)
            
            let fly = SKAction.moveBy(x: 0, y: self.size.height + photon.size.height, duration: 0.5)
            
            let remove = SKAction.removeFromParent()
            
            let fireAndRemove = SKAction.sequence([fly, remove])
            
            photon.run(fireAndRemove)
            
            self.run(self.shootSound)
            
        }
        
    }
    // MARK: - Drop Functions
    func dropThing() {
        
        let dice = Int.random(in: 0..<100)
        // MARK: - RUBRIC 3
        if dice < 3 {
            dropHealth()
        
        } else if dice < 8 {
            dropPowerUp()
            
        } else if dice < 23{
            dropEnemyShip()
            
        } else {
            dropAsteroid()
            
        }
        
    }
    
    // Start asteroid obstacles dropping from random points above the top edge of the screen.
    func dropAsteroid() {
        
        // Define asteroid size.  This will be a random number between 15 and 44
        let sideSize = Double(15 + Int.random(in: 0..<30))
        
        // Maximum x value for the scene - which is the scene's width
        let maxX = Double(self.size.width)
        
        //
        let quarterX = maxX / 4.0
        
        let startX = Double(Int.random(in:0..<Int((maxX + (quarterX * 2))))) - quarterX
        
        let startY = Double(self.size.height) + sideSize
        
        let endX = Double(Int.random(in: 0..<Int(maxX)))
        
        let endY = 0.0 - sideSize
        
        let asteroid = SKSpriteNode(imageNamed: "asteroid")
        asteroid.size = CGSize(width: sideSize, height: sideSize)
        asteroid.position = CGPoint(x: startX, y: startY)
        asteroid.name = ObstacleNodeName
        self.addChild(asteroid)
        
        let move = SKAction.move(to: CGPoint(x: endX, y: endY), duration: Double(3 + Int.random(in: 0..<5)))
        
        let remove = SKAction.removeFromParent()
        let travelAndRemove = SKAction.sequence([move, remove])
        
        let spin = SKAction.rotate(byAngle: 3, duration: Double(Int.random(in: 0..<3) + 1))
        let spinForever = SKAction.repeatForever(spin)
        
        let all = SKAction.group([spinForever, travelAndRemove])
        
        asteroid.run(all)
    }
    
    
    func dropEnemyShip() {
        
        let sideSize = 30.0
        
        let startX = Double(Int.random(in: 0..<(Int(self.size.width - 40))) + 20)
        
        let startY = Double(self.size.height) + sideSize
        
        let enemy = SKSpriteNode(imageNamed: "enemy")
        
        enemy.size = CGSize(width: sideSize, height: sideSize)
        enemy.position = CGPoint(x: startX, y: startY)
        enemy.name = ObstacleNodeName
        
        self.addChild(enemy)
        
        let shipPath = buildEnemyShipMovementPath()
        
        let followPath = SKAction.follow(shipPath, asOffset: true, orientToPath: true, duration: 7.0)
        
        let remove = SKAction.removeFromParent()
        
        let followPathAndRemove = SKAction.sequence([followPath, remove])
        
        enemy.run(followPathAndRemove)
        
    }
    
    func buildEnemyShipMovementPath() -> CGPath {
        
        let yMax = -1.0 * self.size.height
        
        let bezierPath = UIBezierPath()
        
        bezierPath.move(to: CGPoint(x: 0.5, y: -0.5))
        
        bezierPath.addCurve(to: CGPoint(x: -2.5, y: -59.5), controlPoint1: CGPoint(x: 0.5, y: -0.5), controlPoint2: CGPoint(x: 4.55, y: -29.48))
        
        bezierPath.addCurve(to: CGPoint(x: -27.5, y: -154.5), controlPoint1: CGPoint(x: -9.55, y: -89.52), controlPoint2: CGPoint(x: -43.32, y: -115.43))
        
        bezierPath.addCurve(to: CGPoint(x: 30.5, y: -243.5), controlPoint1: CGPoint(x: -11.68, y: -193.57), controlPoint2: CGPoint(x: 17.28, y: -186.95))
        
        bezierPath.addCurve(to: CGPoint(x: -52.5, y: -379.5), controlPoint1: CGPoint(x: 43.72, y: -300.05), controlPoint2: CGPoint(x: -47.71, y: -335.76))
        
        bezierPath.addCurve(to: CGPoint(x: 54.5, y: -449.5), controlPoint1: CGPoint(x: -57.29, y: -423.24), controlPoint2: CGPoint(x: -8.14, y: -482.45))
        
        bezierPath.addCurve(to: CGPoint(x: -5.5, y: -348.5), controlPoint1: CGPoint(x: 117.14, y: -416.55), controlPoint2: CGPoint(x: 52.25, y: -308.62))
        
        bezierPath.addCurve(to: CGPoint(x: 10.5, y: -494.5), controlPoint1: CGPoint(x: -63.25, y: -388.38), controlPoint2: CGPoint(x: -14.48, y: -457.43))
        
        bezierPath.addCurve(to: CGPoint(x: 0.5, y: -559.5), controlPoint1: CGPoint(x: 23.74, y: -514.16), controlPoint2: CGPoint(x: 6.93, y: -537.57))
        
        bezierPath.addCurve(to: CGPoint(x: -2.5, y: yMax), controlPoint1: CGPoint(x: -5.2, y: yMax), controlPoint2: CGPoint(x: -2.5, y: yMax))
        
        return bezierPath.cgPath
        
    }
    
    func dropPowerUp() {
        
        let sideSize = 30.0
        
        let startX = Double(Int.random(in: 0..<Int(self.size.width - 60)) + 30)
        let startY = Double(self.size.height) + sideSize
        let endY = 0 - sideSize
        
        let powerUp = SKSpriteNode(imageNamed: PowerupNodeName)
        
        powerUp.size = CGSize(width: sideSize, height: sideSize)
        powerUp.position = CGPoint(x: startX, y: startY)
        powerUp.name = PowerupNodeName
        
        self.addChild(powerUp)
        
        let move = SKAction.move(to: CGPoint(x: startX, y: endY), duration: 6)
        
        let remove = SKAction.removeFromParent()
        let travelAndRemove = SKAction.sequence([move, remove])
        
        let spin = SKAction.rotate(byAngle: 1, duration: 1)
        let spinForever = SKAction.repeatForever(spin)
        let all = SKAction.group([spinForever, travelAndRemove])
        
        powerUp.run(all)
        
    }
    
    // MARK: - RUBRIC 4
    func dropHealth() {
        
        //  MARK: - RUBRIC 5
        let sideSize = 20.0
        
        //  Determine random starting point for the health above top edge
        let startX = Double(Int.random(in: 0..<Int(self.size.width - 40)) + 20)
        let startY = Double(self.size.height) + sideSize
        let endY = 0 - sideSize
        
        //  MARK: - RUBRIC 6
        let shipHealth = SKSpriteNode(imageNamed: "healthpowerup")
        shipHealth.size = CGSize(width: sideSize, height: sideSize)
        shipHealth.position = CGPoint(x: startX, y: startY)
        // MARK: - RUBRIC 7
        shipHealth.name = HealthNodeName
        
        self.addChild(shipHealth)
        
        //  MARK: - RUBRIC 8
        let move = SKAction.move(to: CGPoint(x: startX, y: endY), duration: 5.0)
        
        let scaleHealth = SKAction.scale(to: -1.5, duration: 20.0)
        let fadeHealth = SKAction.fadeOut(withDuration: 15.0)
        
        // MARK: RUBRIC 9
        let remove = SKAction.removeFromParent()
        let travelAndRemove = SKAction.sequence([move, remove])
        // MARK: - RUBRIC 10
        let scaleAndFade = SKAction.group([scaleHealth, fadeHealth])
        let all = SKAction.group([scaleAndFade, travelAndRemove])
        
        shipHealth.run(all)
    }
    // MARK: - Collisions
    func checkCollisions() {
        
        if let ship = self.childNode(withName: SpaceshipNodeName) {
            
            enumerateChildNodes(withName: PowerupNodeName) {
                powerUp, _ in
                
                if ship.intersects(powerUp) {
                    
                    if let hud = self.childNode(withName: self.HUDNodeName) as!
                        HUDNode? {
                        hud.showPowerupTimer(self.powerUpDuration)
                        
                    }
                    
                    powerUp.removeFromParent()
                    
                    self.shipFireRate = 0.1
                    
                    let powerDown = SKAction.run({
                        self.shipFireRate = self.defaultFireRate
                        
                    })
                    
                    let wait = SKAction.wait(forDuration: self.powerUpDuration)
                    let waitAndPowerDown = SKAction.sequence([wait, powerDown])
                    
                    let powerDownActionKey = "waitAndPowerDown"
                    ship.removeAction(forKey: powerDownActionKey)
                    
                    ship.run(waitAndPowerDown, withKey: powerDownActionKey)
                    
                }
                
            }
            
            enumerateChildNodes(withName: HealthNodeName) {
                shipHealth,  _ in
                
                // MARK: RUBRIC 14B
                let shield = ship.childNode(withName: self.SpaceshipShieldNodeName)
                
                // if ship has collided with one of our health power-ups
                if ship.intersects(shipHealth) {
                    
                    self.shipHealthRate += 1
                    shield?.alpha += 0.25
                    
                    self.run(self.powerSound)
                    
                    shipHealth.removeFromParent()
                    
                    // MARK: RUBRIC 11
                } else  if self.shipHealthRate == 4 {
                    self.shipHealthRate = 4.0
                    shield?.alpha = 1.0
                    shipHealth.removeFromParent()
                }
                
                //  HUD adds health to screen
                if let hud = self.childNode(withName: self.HUDNodeName) as! HUDNode? {
                    let shipHealth = self.shipHealthRate
                    hud.addHealth(Double(shipHealth))
                }
            }
            
            // Loop through all instances of obstacle nodes in the Scene Graph node tree
            enumerateChildNodes(withName: ObstacleNodeName) {
                obstacle, _ in
                
                // MARK: RUBRIC 12
                if ship.intersects(obstacle)  && self.shipHealthRate > 1 {
                    
                    self.shipHealthRate = self.shipHealthRate - 1
                    
                    self.run(self.impactSound)
                    
                    obstacle.removeFromParent()
                    
                    // MARK: RUBRIC 14C
                    let shield = ship.childNode(withName: self.SpaceshipShieldNodeName)
                    shield?.alpha -= 0.25
                    
                    if  let hud = self.childNode(withName: self.HUDNodeName) as! HUDNode? {
                        let shipHealth = self.shipHealthRate
                        
                        hud.addHealth(Double(shipHealth))
                        
                    }
                } else if ship.intersects(obstacle) {
                    
                    self.shipTouch = nil
                    
                    ship.removeFromParent()
                    obstacle.removeFromParent()
                    
                    self.run(self.shipExplodeSound)
                    
                    let explosion = self.shipExplodeTemplate.copy() as! SKEmitterNode
                    
                    explosion.position = ship.position
                    explosion.dieOutInDuration(0.3)
                    self.addChild(explosion)
                    
                    self.endGame()
                    
                }
                
                self.enumerateChildNodes(withName: self.PhotonTorpedoNodeName) {
                    
                    myPhoton, stop in
                    
                    if myPhoton.intersects(obstacle) {
                        
                        myPhoton.removeFromParent()
                        obstacle.removeFromParent()
                        
                        self.run(self.obstacleExplodeSound)
                        
                        // Obstacle Collision Explosions
                        let explosion = self.obstacleExplodeTemplate.copy() as! SKEmitterNode
                            explosion.position = obstacle.position
                            explosion.dieOutInDuration(0.1)
                        self.addChild(explosion)
                        
                        // Update the score
                        if let hud = self.childNode(withName: self.HUDNodeName)
                            as! HUDNode? {
                            
                            let score = 10 * Int(hud.elapsedTime) * (self.easyMode ? 1 : 2)
                            hud.addPoints(score)
                            
                        }
                        
                        // This is like a "break" in other languages.
                        stop.pointee = true
                        
                    }
                    
                }
                
            }
            
        }
        
    }
    
    // MARK: - End Game
    func endGame()
        
    {   if let view = self.view {
            
            tapGesture = UITapGestureRecognizer(target: self, action: #selector(GameScene.tapped))
            view.addGestureRecognizer(tapGesture!)
            let node = GameOverNode()
            node.position = CGPoint(x: self.size.width/2.0, y: self.size.height/2.0)
            addChild(node)
            
        }
        
        let hud = childNode(withName: HUDNodeName) as! HUDNode
        hud.endGame()
        
        let defaults = UserDefaults.standard
        let highScore = defaults.value(forKey: "highScore")
        
            if ((highScore as AnyObject).integerValue < hud.score) {
            defaults.setValue(hud.score, forKey: "highScore")
            
        }
        
    }
    
    @objc func tapped() {
        if let endGameCallback = endGameCallback {
            endGameCallback()
            
        }
        
    }
    
    override func willMove(from view: SKView) {
        if let view = self.view {
            if tapGesture != nil {
                view.removeGestureRecognizer(tapGesture!)
                tapGesture = nil
                
            }
            
        }
        
    }
    
}
