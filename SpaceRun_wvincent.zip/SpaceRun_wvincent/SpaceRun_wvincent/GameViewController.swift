//
//  GameViewController.swift
//  SpaceRun_wvincent
//
//  Created by Vincent, II, William on 4/29/19.
//  Copyright © 2019 CVTC William Vincent II. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    
    var easyMode: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let skView = self.view as! SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        
        //skView.ignoresSiblingOrder = true
        
        // let scene = GameScene(size: skView.bounds.size)
        
        //scene.backgroundColor = SKColor.black
        
        //scene.scaleMode = .aspectFill
        
        //scene.endGameCallback = { [weak self] in
        //if let weakSelf = self {
        
        // weakSelf.navigationController?.popToRootViewController(animated: true)
        
        // }
        
        //  }
        
        // skView.presentScene(scene)
        
        let blackScene = SKScene(size: skView.bounds.size)
        blackScene.backgroundColor = SKColor.black
        skView.presentScene(blackScene)
        
    }
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations:
        UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
            
        } else {
            
            return .all
        }
        
    }
    override var prefersStatusBarHidden: Bool {
        
        return true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let skView = self.view as! SKView
        
        let openingScene = OpeningScene(size: skView.bounds.size)
        openingScene.scaleMode = .aspectFill
        let transition = SKTransition.fade(withDuration: 1.0)
        skView.presentScene(openingScene, transition: transition)
        
        openingScene.sceneEndCallback = { [weak self] in
            if let weakSelf = self {
                let scene = GameScene(size: skView.bounds.size)
                
                scene.backgroundColor = SKColor.black
                
                scene.easyMode = weakSelf.easyMode
                
                scene.endGameCallback = { [weak self] in
                    if let ws = self {
                        // Push presentation
                        ws.navigationController?.popToRootViewController(animated: true)
                        
                        // Modal presentation
                        // ws.dismissViewControllerAnimated(true, completion: nil
                        
                    }
                    
                    
                }
                
                
                skView.presentScene(scene)
            }
            
            
        }
        
    }
    
}
