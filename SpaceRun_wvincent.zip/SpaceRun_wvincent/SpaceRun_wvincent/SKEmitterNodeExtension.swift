//
//  SKEmitterNodeExtension.swift
//  SpaceRun_wvincent
//
//  Created by Vincent, II, William on 5/6/19.
//  Copyright © 2019 CVTC William Vincent II. All rights reserved.
//

import SpriteKit

extension SKEmitterNode{
    
    func dieOutInDuration(_ duration: TimeInterval) {
        
        // Get the first wait time.
        let firstWait = SKAction.wait(forDuration: duration)
        
        // set the birth rate to zero in order to make the particle disappear using
        // and SKAction code block.
        let stop = SKAction.run({
            
            [weak self] in
            
            if let weakSelf = self {
                weakSelf.particleBirthRate = 0
                
            }
            
        })
        
        // Get the second wait time
        let secondWait = SKAction.wait(forDuration: TimeInterval(self.particleLifetime))
        
        // Set up removal from parent
        let remove = SKAction.removeFromParent()
        
        let dieOut = SKAction.sequence([firstWait, stop, secondWait, remove])
        
        run(dieOut)
        
    }
}


